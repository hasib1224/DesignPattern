package SmellAndProblemIdentify;

//Lazy Class
public class Document {
    //Nothing here
}
