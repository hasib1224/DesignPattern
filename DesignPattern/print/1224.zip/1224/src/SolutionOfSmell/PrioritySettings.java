package SolutionOfSmell;

import SmellAndProblemIdentify.Document;
import java.util.Queue;

public class PrioritySettings {
    HighToonerSave highTonerSaveMode = new HighToonerSave();
    LowToonerSave lowTonerSaveMode = new LowToonerSave();
    MediumToonerSave mediumTenorSaveMode = new MediumToonerSave();
    Document document = new Document();
    Queue<Object> PrintRequest ;

    public void changePriority()
    {

    }
}
