package SolutionOfSmell;

public class LowToonerSave extends PrintMode{
    @Override
    public void printerAlgorithm() {
        System.out.println("Here is the Algo");
    }
}
