package SolutionOfSmell;

public abstract class PrintMode {
    //    public int numberOfPage,pageSize,costPerPage;
//    String colorIntensity = "low",orientation="Pottrsit";

    public abstract void printerAlgorithm();
}
