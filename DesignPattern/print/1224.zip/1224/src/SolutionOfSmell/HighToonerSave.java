package SolutionOfSmell;

public class HighToonerSave extends PrintMode {
    @Override
    public void printerAlgorithm() {
        System.out.println("Here is the Algo");

    }
}
