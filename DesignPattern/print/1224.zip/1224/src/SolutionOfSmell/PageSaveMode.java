package SolutionOfSmell;

public class PageSaveMode extends PrintMode{
    @Override
    public void printerAlgorithm() {
        System.out.println("Here is the Algo");
    }
    public void renderPreview()
    {

    }
}
