package SolutionOfSmell;

public class BoosterMode extends PrintMode{
    @Override
    public void printerAlgorithm() {
        System.out.println("Here is the Algo");
    }

    public void boots()
    {
        System.out.println("Here is another Algo");

    }

}
