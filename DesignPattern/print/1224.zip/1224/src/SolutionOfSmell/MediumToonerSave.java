package SolutionOfSmell;

public class MediumToonerSave extends PrintMode{
    @Override
    public void printerAlgorithm() {
        System.out.println("Here is the Algo");
    }
}
