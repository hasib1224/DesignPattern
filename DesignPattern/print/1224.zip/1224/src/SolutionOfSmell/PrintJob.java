package SolutionOfSmell;

import javax.swing.text.Document;
import java.util.Queue;

public class PrintJob {
    public void pullJob()
    {

    }
}
